#!/usr/bin/env python3
"""
Integration test for MCN Flutter UI Generator
"""

import sys
import os
import json
import shutil

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, '..'))

def test_flutter_bindings():
    print("=== Testing MCN Flutter Project Generator ===")
    
    try:
        sys.path.insert(0, _REPO_ROOT)
        from mcn.core_engine.mcn_ui_bindings import UIBindingManager
        
        ui_manager = UIBindingManager()
        
        # Define a mock page with widgets
        title = ui_manager.text("Welcome to ClopsAI Mobile", tag="h1")
        sub = ui_manager.text("Enter your name to register:", tag="p")
        name_input = ui_manager.input("Name", "name_entered")
        submit_btn = ui_manager.button("Submit Details", "submit_data")
        
        container = ui_manager.container([title, sub, name_input, submit_btn], className="main-col")
        
        # Chart and Table components
        sales_chart = ui_manager.chart("line", "sales_data")
        orders_table = ui_manager.table(["ID", "User", "Total"], "orders_list")
        
        # Pages
        ui_manager.create_page("Home", "/", [container])
        ui_manager.create_page("Dashboard", "/dashboard", [sales_chart, orders_table])
        
        # Test Directory
        test_dir = os.path.join(_REPO_ROOT, "test", "flutter_test_output")
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
            
        # Export
        ui_manager.export_to_flutter_project(test_dir)
        print("Flutter project successfully generated.")
        
        # Verify files
        expected_files = [
            "pubspec.yaml",
            "ui-manifest.json",
            "lib/main.dart",
            "lib/services/mcn_client.dart",
            "lib/widgets/ui_components.dart",
            "lib/pages/HomePage.dart",
            "lib/pages/DashboardPage.dart"
        ]
        
        all_present = True
        for f in expected_files:
            p = os.path.join(test_dir, f)
            if os.path.exists(p):
                print(f"[OK] file exists: {f}")
            else:
                print(f"[FAIL] missing file: {f}")
                all_present = False
                
        # Basic content verification on HomePage
        home_path = os.path.join(test_dir, "lib/pages/HomePage.dart")
        with open(home_path, 'r') as fh:
            content = fh.read()
            if "UIInput" in content and "UIButton" in content and "UIText" in content:
                print("[OK] HomePage has expected child widgets")
            else:
                print("[FAIL] HomePage does not contain child widgets correctly")
                all_present = False
                
        # Basic content verification on DashboardPage
        dash_path = os.path.join(test_dir, "lib/pages/DashboardPage.dart")
        with open(dash_path, 'r') as fd:
            content = fd.read()
            if "UIChart" in content and "UITable" in content:
                print("[OK] DashboardPage has expected chart and table widgets")
            else:
                print("[FAIL] DashboardPage does not contain chart or table widgets")
                all_present = False
                
        return all_present

    except Exception as e:
        print(f"Flutter generator test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_flutter_bindings()
    sys.exit(0 if success else 1)
