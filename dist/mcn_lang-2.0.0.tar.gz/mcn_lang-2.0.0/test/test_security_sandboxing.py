#!/usr/bin/env python3
import sys
import os
import unittest
import tempfile
import shutil
import sqlite3

# Add repo root to path
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, '..'))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from mcn.plugin.mcn_embedded import MCNEmbedded

class TestSecuritySandboxing(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_infinite_loop_prevention(self):
        """Verify that infinite loops are terminated by max_steps limit"""
        mcn = MCNEmbedded(max_steps=50)
        script = """
        var count = 0
        while true
            count = count + 1
        """
        with self.assertRaises(Exception) as ctx:
            mcn.execute(script)
        self.assertIn("Maximum statement execution limit of 50 exceeded", str(ctx.exception))

    def test_infinite_recursion_prevention(self):
        """Verify that infinite recursions are terminated by max_steps limit"""
        mcn = MCNEmbedded(max_steps=30)
        script = """
        function recurse()
            return recurse()
        
        recurse()
        """
        with self.assertRaises(Exception) as ctx:
            mcn.execute(script)
        self.assertIn("Maximum statement execution limit of 30 exceeded", str(ctx.exception))

    def test_path_sandboxing_inside(self):
        """Verify file operations inside sandbox work normally"""
        mcn = MCNEmbedded(sandbox_dir=self.temp_dir)
        script = """
        write_file("test.txt", "hello sandbox")
        var content = read_file("test.txt")
        content
        """
        result = mcn.execute(script)
        self.assertEqual(result, "hello sandbox")
        
        # Verify it was actually written inside temp_dir
        expected_file = os.path.join(self.temp_dir, "test.txt")
        self.assertTrue(os.path.exists(expected_file))
        with open(expected_file, "r") as f:
            self.assertEqual(f.read(), "hello sandbox")

    def test_path_sandboxing_traversal_outside(self):
        """Verify path traversal attempting to escape sandbox is blocked"""
        mcn = MCNEmbedded(sandbox_dir=self.temp_dir)
        
        # Create a file outside the sandbox
        outside_dir = tempfile.mkdtemp()
        outside_file = os.path.join(outside_dir, "sensitive.txt")
        with open(outside_file, "w") as f:
            f.write("secret data")
            
        try:
            # Attempt to write outside the sandbox
            script_write = f'write_file("{outside_file}", "hacked")'
            with self.assertRaises(Exception) as ctx:
                mcn.execute(script_write)
            self.assertIn("Sandbox violation", str(ctx.exception))
            
            # Verify file was not written/overwritten
            with open(outside_file, "r") as f:
                self.assertEqual(f.read(), "secret data")
                
            # Attempt to read outside the sandbox via relative path traversal
            relative_traversal = "../sensitive.txt"
            script_read = f'read_file("{relative_traversal}")'
            with self.assertRaises(Exception) as ctx:
                mcn.execute(script_read)
            self.assertIn("Sandbox violation", str(ctx.exception))
        finally:
            shutil.rmtree(outside_dir, ignore_errors=True)

    def test_dynamic_db_swapping(self):
        """Verify tenant database connections can be dynamically swapped"""
        # Create two separate SQLite databases
        db_path_1 = os.path.join(self.temp_dir, "tenant_1.db")
        db_path_2 = os.path.join(self.temp_dir, "tenant_2.db")
        
        conn1 = sqlite3.connect(db_path_1)
        conn1.execute("CREATE TABLE data (val TEXT)")
        conn1.execute("INSERT INTO data VALUES ('Tenant 1 Data')")
        conn1.commit()
        
        conn2 = sqlite3.connect(db_path_2)
        conn2.execute("CREATE TABLE data (val TEXT)")
        conn2.execute("INSERT INTO data VALUES ('Tenant 2 Data')")
        conn2.commit()
        
        mcn = MCNEmbedded()
        
        script = """
        var res = query("SELECT val FROM data")
        res[0].val
        """
        
        # Test Tenant 1 connection
        result1 = mcn.execute(script, db_connection=conn1)
        self.assertEqual(result1, "Tenant 1 Data")
        
        # Test Tenant 2 connection
        result2 = mcn.execute(script, db_connection=conn2)
        self.assertEqual(result2, "Tenant 2 Data")
        
        conn1.close()
        conn2.close()

if __name__ == "__main__":
    unittest.main()
