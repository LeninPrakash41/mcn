#!/usr/bin/env python3
"""
Integration test for MCN Auth Auto-Generation and Stripe Enhancements
"""

import sys
import os
import shutil

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, '..'))

def test_auth_auto_generation():
    print("=== Testing MCN auth_auto Package ===")
    
    try:
        sys.path.insert(0, _REPO_ROOT)
        from mcn.core_engine.mcn_interpreter import MCNInterpreter
        
        interpreter = MCNInterpreter()
        
        # Run MCN code importing auth_auto
        mcn_code = """
        use "auth_auto"
        use "ui"
        
        // Setup an export target to test generation of auth pages
        ui_export("test/auth_export_output")
        """
        
        interpreter.execute(mcn_code)
        print("[OK] auth_auto package load and page registration completed.")
        
        # Verify database table exists (in-memory SQLite by default)
        users = interpreter.runtime.query("SELECT name FROM sqlite_master WHERE type='table' AND name='auth_users'")
        if users:
            print("[OK] Database users table automatically created.")
        else:
            print("[FAIL] Database users table missing.")
            return False
            
        # Verify UI pages were registered
        ui_manager = interpreter.ui_integration.ui_manager
        if "Login" in ui_manager.pages and "Register" in ui_manager.pages:
            print("[OK] Login and Register UI pages automatically registered.")
        else:
            print("[FAIL] Missing registered UI pages.")
            return False
            
        # Verify registration endpoint logic
        reg_fn = interpreter.functions.get("register_user")
        login_fn = interpreter.functions.get("login_user")
        
        if not reg_fn or not login_fn:
            print("[FAIL] Missing registered backend logic handlers.")
            return False
            
        # Test register
        interpreter.runtime.query("DELETE FROM auth_users")
        reg_res = reg_fn({"email": "test@clops.ai", "password": "supersecretpassword"})
        if reg_res.get("success"):
            print("[OK] Backend registration logic works.")
        else:
            print(f"[FAIL] Backend registration logic failed: {reg_res}")
            return False
            
        # Test login
        login_res = login_fn({"email": "test@clops.ai", "password": "supersecretpassword"})
        if login_res.get("success") and "token" in login_res:
            print("[OK] Backend login logic and JWT generation works.")
        else:
            print(f"[FAIL] Backend login logic failed: {login_res}")
            return False
            
        # Clean up output
        out_dir = os.path.join(_REPO_ROOT, "test", "auth_export_output")
        if os.path.exists(out_dir):
            shutil.rmtree(out_dir)
            
        return True

    except Exception as e:
        print(f"auth_auto test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_stripe_enhancements():
    print("\n=== Testing Stripe Package Enhancements ===")
    
    try:
        sys.path.insert(0, _REPO_ROOT)
        from mcn.core_engine.mcn_interpreter import MCNInterpreter
        
        interpreter = MCNInterpreter()
        
        mcn_code = """
        use "stripe"
        
        var pi = create_payment_intent(100.0, "usd")
        var session = create_checkout_session(
            "https://clopsai.com/success",
            "https://clopsai.com/cancel",
            [{"price": "price_123", "quantity": 1}]
        )
        
        log(pi)
        log(session)
        """
        
        interpreter.execute(mcn_code)
        
        # Verify vars in global scope
        pi = interpreter.variables.get("pi")
        session = interpreter.variables.get("session")
        
        if pi and "client_secret" in pi and pi.get("status") == "requires_payment_method":
            print("[OK] create_payment_intent returns proper intent structures.")
        else:
            print(f"[FAIL] create_payment_intent failed or returned invalid response: {pi}")
            return False
            
        if session and "url" in session and "cs_mock" in session.get("id"):
            print("[OK] create_checkout_session returns proper checkout session structures.")
        else:
            print(f"[FAIL] create_checkout_session failed or returned invalid response: {session}")
            return False
            
        return True

    except Exception as e:
        print(f"Stripe enhancements test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    auth_ok = test_auth_auto_generation()
    stripe_ok = test_stripe_enhancements()
    
    sys.exit(0 if (auth_ok and stripe_ok) else 1)
